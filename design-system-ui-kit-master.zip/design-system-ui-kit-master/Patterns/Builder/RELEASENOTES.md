# Release notes

<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

<!-- ## [Unreleased] -->

## 1.0.0 - 2018-06-19

### Initial release

* Added Nodes
* Created Instructions
* Added File Overview
* Added Panels
* Added Wireframes
* Added Typography
* Added Zoom Tool
* Added Click to Create
* Added Builder Header